﻿
namespace Ink.Runtime
{
	internal interface INamedContent
	{
		string name { get; }
		bool hasValidName { get; }
	}
}

