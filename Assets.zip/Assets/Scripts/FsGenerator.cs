using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FsClasses{
    public class FsGenerator {
    public TKey RandomValues<TKey, TValue>(IDictionary<TKey, TValue> dict){
        System.Random rand = new System.Random();
        List<TKey> values = Enumerable.ToList(dict.Keys);
        int size = dict.Count;
        return values[rand.Next(size)];
    }
    public Reason ReasonGenerator() {
        System.Random rand = new System.Random();
        Dictionary<string, string> giftee = new Dictionary<string, string>()
            {
                {"brother's", "his"}, 
                {"sister's", "her"}, 
                {"grandma's", "her"}, 
                {"girlfriend's", "her"}, 
                {"boyfriend's", "his"},
                {"friend's", "their"},
                {"boss's", "their"}
            };
        Dictionary<string, List<string>> occasion = new Dictionary<string, List<string>>() 
            {
                {"funeral", new List<string>{"sunflower", "chrysanthenum"}},
                {"wedding", new List<string>{"peony", "aster", "rose"}},
                {"birthday", new List<string>{"tulip", "aster"}},
                {"anniversary", new List<string>{"rose", "peony"}}
            };
        string g = RandomValues(giftee);
        string o = RandomValues(occasion);
        return new Reason(g, o, occasion[o], giftee[g]);
    }

    public Order OrderGenerator(int orderNum) {
        System.Random rnd = new System.Random();
        int daysLeft = rnd.Next(1,5);
        List<string> names = new List<string> {"Billy", "Joel", "Sue", "Amanda", "Alex", "Jordan", "Julia"};
        List<string> colors = new List<string> {"red", "blue", "yellow"};
        string name = names[rnd.Next(names.Count)];
        string color = colors[rnd.Next(colors.Count)];
        return new Order(orderNum, name, ReasonGenerator(), color, daysLeft);
    }

    public List<Flower> Flowers() {
        List<Flower> flowers = new List<Flower>() {
            new Flower("aster", "wisdom, devotion", 3, new List<string>{"red", "white", "pink"}),
            new Flower("chrysanthenum", "loyalty, love", 2, new List<string>{"red", "yellow", "white", "green"}),
            new Flower("rose", "love, passion", 5, new List<string>{"red", "orange", "yellow", "pink", "white"}),
            new Flower("sunflower", "admiration, loyalty", 3, new List<string>{"yellow", "red", "orange"}),
            new Flower("tulip", "love, confidence", 2, new List<string>{"pink", "white", "yellow"}),
            new Flower("peony", "romance, prosperity", 1, new List<string>{"red", "white", "pink"}),
        };
        return flowers;
    }

    public bool checkColors(string favorite, string flower){
        List<string> colors = new List<string> {"red","pink", "blue", "green", "yellow", "orange"};
        if (flower=="white") {return true;}
        if (favorite=="red") {
            if (colors.GetRange(0,2).Contains(flower)||flower =="orange") {return true;}
            else {return false;}            
        } else if (favorite=="orange") {
            if (colors.GetRange(4, 2).Contains(flower) || flower == "red") {return true;}
            else {return false;}
        } else {
            int ind = colors.FindIndex(x=>x==favorite);
            if (colors.GetRange(ind-1, 3).Contains(flower)) {return true;}
            else {return false;}
        }
    }

    public string makeResponse(bool happy){
        System.Random rnd = new System.Random();
        List<string> responses = new List<string> {
            "Thank you! I'm sure they'll love it", 
            "Thank you! These are lovely!", 
            "Oh these are wonderful! Thank you!",
            "Wow what a great job! I'll be sure to come back!",
            "Oh, are these for me? They're definitely not what I was expecting...",
            "Ugh this wasn't what I was thinking at all. See if I come back!",
            "What were you thinking? These are hideous!",
            "I'm never coming back"
        };
        if (happy) {return responses[rnd.Next(0, 3)];
        } else {return responses[rnd.Next(4,7)];}
    }
    }
}