﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using FsClasses;

public class OrderScript : MonoBehaviour
{
    public Button nextButton, prevButton;
    public Text orderText, orderCount;
    List<Order> currOrders;
    Order curr;
    int display = 0;
    void Start() {
        nextButton.onClick.AddListener(Next);
        prevButton.onClick.AddListener(Prev);
    }

    void Update() {
        if (display == currOrders.Count-1 || currOrders.Count == 0) {
            nextButton.gameObject.SetActive(false);
        } else {nextButton.gameObject.SetActive(true);}
        if (display == 0) {
            prevButton.gameObject.SetActive(false);
        } else {prevButton.gameObject.SetActive(true);}
        if (currOrders.Count > 0) {
            orderCount.text = (display+1).ToString()+"/"+currOrders.Count.ToString();
            curr = currOrders[display];
            orderText.text = "Order: "+curr.orderNum+" for "+curr.name+"\n\tOccasion: "+curr.restring+
                "\n\tColor: "+curr.color+"\n\tNeeded in: "+curr.daysLeft+" days\n";
        } else {orderText.text = "";}

    }
    public void ManageOrders(List<Order> orderList) {
        display = 0;
        currOrders = orderList;
    }

    public void Next() {
        display++;
    }

    public void Prev() {
        display--;
    }
}
