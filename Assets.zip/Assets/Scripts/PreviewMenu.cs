﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using FsClasses;

public class PreviewMenu : MonoBehaviour
{
    public Button flower1, flower2, flower3, flower4, flower5;
    public FsManager manager;
    List<Button> flowerButtons;

    FsGenerator fs = new FsGenerator();

    void Awake() {
        flowerButtons = new List<Button>{flower1, flower2, flower3, flower4, flower5};
        flowerButtons.ForEach(x=> x.gameObject.SetActive(false));
    }

    public void ClearMenu(){
        flowerButtons.ForEach(x=> 
        {x.gameObject.SetActive(false);
        x.onClick.RemoveAllListeners();});
    }

    public void MakeMenu(List<string> list){
        for (int i=0; i<list.Count; i++) {
            string[] flower = list[i].Split();
            flowerButtons[i].gameObject.SetActive(true);
            Image icon = flowerButtons[i].transform.GetChild(0).GetComponent<Image>();
            icon.sprite = Resources.Load<Sprite>(flower[1]);
            icon.color = GetColor(flower[0]);
            flowerButtons[i].onClick.AddListener(delegate{HandleClick(i);});
        }
    }

    void HandleClick(int i) {
        manager.removeFromOrder(i);
    }

    public Color GetColor(string color) {
        if (color == "red") { return Color.red;}
        else if (color == "pink") {return Color.magenta;}
        else if (color == "blue") {return Color.blue;}
        else if (color == "green") {return Color.green;}
        else if (color == "yellow") {return Color.yellow;}
        else {return Color.white;}
    }
}
