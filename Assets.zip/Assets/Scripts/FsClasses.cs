﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FsClasses {
public class Order
{
    public int orderNum, daysLeft;
    public string name, flower, color, restring;
    public Reason reason;
    public Order(int orderNum, string name, Reason reason, string color, int daysLeft) {
        this.orderNum = orderNum;
        this.name = name;
        this.reason = reason;
        this.restring = reason.giftee+" "+reason.occasion;
        this.color = color;
        this.daysLeft = daysLeft;

    }
}

public class Flower 
{
    public string name, meaning;
    public int cost;
    public List<string> colors;
    public Flower(string name, string meaning, int cost, List<string> colors) {
        this.name = name;
        this.meaning = meaning;
        this.cost = cost;
        this.colors = colors;
    }
}

public class Reason
{
    public string giftee, occasion, pronoun;
    public List<string> flowers;
    public Reason(string giftee, string occasion, List<string> flowers, string pronoun) {
        this.giftee = giftee;
        this.occasion = occasion;
        this.flowers = flowers;
        this.pronoun = pronoun;
    }
}

public class StockItem
{
    public string item, color, flower;
    public int quantity;
    public StockItem(string color, string flower, int quantity) {
        this.item = color+" "+flower;
        this.color = color;
        this.flower = flower;
        this.quantity = quantity;
    }
}
}