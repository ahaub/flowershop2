﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using FsClasses;

public class SampleButton : MonoBehaviour
{
    public Button buttonComponent;
    public Text flowerLabel, stockLabel;
    public Image flowerImage;
    private FsManager manager;
    void Start()
    {
        buttonComponent.onClick.AddListener(HandleClick);
    }
    public void Setup(StockItem item, FsManager currmanager)
    {
        flowerLabel.text = item.item;
        stockLabel.text = item.quantity.ToString();
        manager = currmanager;
        flowerImage.sprite = Resources.Load<Sprite>(item.flower);
        flowerImage.color = GetColor(item.color);
    }

    void HandleClick()
    {
        manager.addToOrder(flowerLabel.text);
    }

    Color GetColor(string color) {
        if (color == "red") { return Color.red;}
        else if (color == "pink") {return Color.magenta;}
        else if (color == "blue") {return Color.blue;}
        else if (color == "green") {return Color.green;}
        else if (color == "yellow") {return Color.yellow;}
        else {return Color.white;}
    }
}
