﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using FsClasses;

public class Customer : MonoBehaviour
{
    public GameObject customer, phone, thoughts;
    Text speech, call, thought;
    FsGenerator fs = new FsGenerator();
    string saying;
    public Image customerSprite;
    public bool talking, runPopQueue=false; float counter; int charsDisplayed; 
    bool popQueueRunning=false;
    List<Order> queue = new List<Order>();
    List<Order> currOrders;
    void Start() {
        speech = customer.GetComponentInChildren<Text>();
        call = phone.GetComponentInChildren<Text>(); 
        thought = thoughts.GetComponentInChildren<Text>();
        customer.SetActive(false); phone.SetActive(false); thoughts.SetActive(false);
    }
    void Update() {
        if (customer.activeSelf) {
            StartCoroutine(UpdateSpeech(speech, customer));
        }
        if (phone.activeSelf){
            StartCoroutine(UpdateSpeech(call, phone));
        }
        if (thoughts.activeSelf){
            StartCoroutine(UpdateSpeech(thought, thoughts));
        }
        if (runPopQueue && !popQueueRunning) {
            StartCoroutine(PopQueue(currOrders));
        }
    }

    public void RunPopQueue(List<Order> orders){
        currOrders = orders;
        runPopQueue=true;
    }
    public void Order(Order or, string orderer="customer") {
        if (orderer == "customer") {customer.SetActive(true);}
        else {phone.SetActive(true);}
        saying = "I need a bouquet for my "+or.restring+". "+or.reason.pronoun+
            " favorite color is "+or.color;
        talking = true;
        charsDisplayed = 0;
    }
    public void Respond(bool happy, string responder="customer") {
        if (responder == "customer") {customer.SetActive(true);}
        else {phone.SetActive(true);}
        saying = fs.makeResponse(happy);
        talking = true;
        charsDisplayed = 0;
    }

    public void Think(string thinking){
        thoughts.SetActive(true);
        saying = thinking;
        talking = true;
        charsDisplayed = 0;
    }

    IEnumerator UpdateSpeech(Text txt, GameObject parent) {
        if (talking){
            if (charsDisplayed < saying.Length) {
                charsDisplayed++;
                txt.text = saying.Substring(0, charsDisplayed);
            } else {
                yield return new WaitForSeconds(1.0f); 
                talking = false; parent.SetActive(false);}
        }
    }

    public void AddToQueue(Order or, string orderer="customer") {
        if (!popQueueRunning){queue.Add(or);}
        else {
            Debug.Log("waiting");
            while(popQueueRunning){}
            queue.Add(or);
        }
        Debug.Log("Orders in Queue: "+queue.Count.ToString());
    }

    IEnumerator PopQueue(List<Order> orders) {
        popQueueRunning = true;
        for (int i=0; i < queue.Count; i++) {
            Order or = queue[i];
            orders.Add(or);
            Order(or);
            yield return new WaitUntil(() => !talking);
            yield return new WaitForSeconds(1.0f);
        }
        queue.Clear();
        runPopQueue = false;
        popQueueRunning = false;
    }

    public int QueueOpen() {return (queue.Count);}
}
