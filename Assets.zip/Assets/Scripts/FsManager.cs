﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using FsClasses;

public class FsManager : MonoBehaviour
{
    System.Random rnd = new System.Random();
    public Text cashText, happyText, dayText, centerText, priceText;
    public GameObject OrderMenu, stockMenu, ordersMenu, greetCustButton;
    public PreviewMenu previewMenu;
    public OrderScript orderScript;
    public Transform stockContent;
    public Dropdown colorDrop, flowerDrop, quantityDrop, stockDrop;
    public Image flowerOrder;
    public Customer customer;
    int happy=0, cash=200, day=1, orderNum=1, daysOrders=0;
    float timer=0f, stopTime;
    string lastOrderButton;
    List<Order> currOrders = new List<Order>(){};
    List<string> workingOrder = new List<string>(){};
    List<StockItem> stock = new List<StockItem>();
    List<StockItem> enRoute = new List<StockItem>();
    FsGenerator fs = new FsGenerator();
    List<Flower> flowList;
    public SimpleObjectPool stockObjectPool;
    void Start()
    {
        UpdateText();
        OrderMenu.SetActive(false);
        stockMenu.SetActive(false);
        ordersMenu.SetActive(false);
        greetCustButton.SetActive(false);
        currOrders.Add(fs.OrderGenerator(orderNum));
        orderNum++;
        stopTime = rnd.Next(5, 20);
        flowList = fs.Flowers();
        flowerDrop.onValueChanged.AddListener(delegate {runStockMenu(flowerDrop.value);});
        colorDrop.onValueChanged.AddListener(delegate {runStockMenu(flowerDrop.value);});
        runStockMenu(flowerDrop.value);
    }

    void Update()
    {
        if (daysOrders < day) {
            if (timer<stopTime){
                timer += Time.deltaTime;
            } else {
                Order or = Ordering(orderNum);
                customer.AddToQueue(or);
                greetCustButton.SetActive(true);
                orderNum++; daysOrders++;
                stopTime = rnd.Next(5, 20);
                timer = 0;
            }
        }
        if (customer.QueueOpen() == 0) {greetCustButton.SetActive(false);}
    }

    public void CheckOrders()
    {
        if (ordersMenu.activeSelf){
            ordersMenu.SetActive(false);
        } else {
            ordersMenu.SetActive(true);
            orderScript.ManageOrders(currOrders);
        }
    }

    public void GreetCustomers() {
        if (customer.QueueOpen() > 0) {
            //Debug.Log("greet customers called");
            customer.RunPopQueue(currOrders);
            greetCustButton.SetActive(false);}
    }

    /*public void CheckMeanings()
    {
        string output = "";
        flowList.ForEach(x=>{output+=x.name+" ($"+x.cost+"): "+x.meaning+"\n";});
        output+="\n Flowers Arriving Tomorrow:\n";
        enRoute.ForEach(x=>{output+=x.item+", "+x.quantity+"\n";});        
        centerText.text = output;
    }*/

    public void NextDay()
    {
        day++;
        enRoute.ForEach(x=>
            {if(stock.Exists(y=> x.item == y.item)){
                stock.Find(y=> x.item == y.item).quantity+=x.quantity;
            } else {
                stock.Add(x);}});
        enRoute.Clear();
        currOrders.ForEach(x=>
            {x.daysLeft--;
            if (x.daysLeft < 0) {
                currOrders.Remove(x);
                happy-=20;
            }});
        UpdateText();
        daysOrders=0;
    }

    void UpdateText()
    {
        cashText.text = "Cash: "+cash.ToString();
        happyText.text = "Happy: "+happy.ToString();
        dayText.text = "Day: "+day.ToString();
    }

    public void FlowersMenu(bool make) 
    { 
        if (OrderMenu.activeSelf || stockMenu.activeSelf) {
            OrderMenu.SetActive(false);
            stockMenu.SetActive(false);
            colorDrop.value = 0; flowerDrop.value = 0;
        } else {
            colorDrop.ClearOptions(); flowerDrop.ClearOptions(); stockDrop.ClearOptions();
            if (make) {
                stockMenu.SetActive(true);
                lastOrderButton = "make";
                List<string> orderNums = new List<string>();
                currOrders.ForEach(x=>orderNums.Add(x.orderNum.ToString()));
                stockDrop.AddOptions(orderNums);
                UpdateStock();
            } else {
                OrderMenu.SetActive(true);
                colorDrop.gameObject.SetActive(false);
                lastOrderButton = "order";
                List<string> flowersList = new List<string> {"flower"};
                flowList.ForEach(x=> flowersList.Add(x.name));
                flowersList.Add("Ordered");
                flowerDrop.AddOptions(flowersList);
                quantityDrop.value = 4;
            }
        }
    }

    public void OrderFlowers() 
    {
        if (lastOrderButton=="make") {MakeFlowers();
        } else {OrderStock();}
    }

    public Order Ordering(int orderNum) {
        return fs.OrderGenerator(orderNum);
    }

    void UpdateStock() {
        foreach (StockItem s in stock.ToArray()){
            if (s.quantity == 0) {stock.Remove(s);}}
        RemoveButtons(); AddButtons();
    }

    private void RemoveButtons()
    {
        while (stockContent.childCount > 0) 
        {
            GameObject toRemove = stockContent.GetChild(0).gameObject;
            stockObjectPool.ReturnObject(toRemove);
        }
    }

    private void AddButtons() {
        for (int i = 0; i < stock.Count; i++) 
        {
            StockItem item = stock[i];
            GameObject newButton = stockObjectPool.GetObject();
            newButton.transform.SetParent(stockContent, false);

            SampleButton sampleButton = newButton.GetComponent<SampleButton>();
            sampleButton.Setup(item, this);
        }
    }

    public void addToOrder(string flower) {
        if (workingOrder.Count <= 5){
            workingOrder.Add(flower);
            stock.Find(y=> y.item == flower).quantity--;
            UpdateStock();
            previewMenu.MakeMenu(workingOrder);
        }
        else {Debug.Log("too many flowers!");}
    }

    public void removeFromOrder(int i) {
        string temp = workingOrder[i-1];
        workingOrder.RemoveAt(i-1);
        if (stock.Exists(x=>x.item == temp)){stock.Find(x=>x.item == temp).quantity++;}
        else {stock.Add(toStock(temp, 1));}
        UpdateStock();
        previewMenu.ClearMenu();
        if (workingOrder.Count > 0) {previewMenu.MakeMenu(workingOrder);}    
    }

    public StockItem toStock(string flow, int quan){
        string[] split = flow.Split();
        return new StockItem(split[0], split[1], quan);
    }

    public void runStockMenu(int flowVal) {
        if (flowVal == 0) {
            colorDrop.gameObject.SetActive(false);
            quantityDrop.gameObject.SetActive(false);
            centerText.text = ""; priceText.text = "";
            flowerOrder.color = Color.clear;
        } else if (flowVal == (flowerDrop.options.Count-1)) {
            colorDrop.gameObject.SetActive(false);
            quantityDrop.gameObject.SetActive(false);
            flowerOrder.color = Color.clear;
            string output = "";
            output+= "Flowers Arriving Tomorrow:\n";
            enRoute.ForEach(x=>{output+=x.item+", "+x.quantity+"\n";});
            centerText.text = output; priceText.text = "";
        } else {
            colorDrop.gameObject.SetActive(true);
            quantityDrop.gameObject.SetActive(true);
            string flower = flowerDrop.options[flowerDrop.value].text;
            Flower flow = flowList.Find(x=> x.name == flower);
            List<string> colors = flow.colors;
            if (colorDrop.value > colors.Count) {colorDrop.value = 0;}
            colorDrop.ClearOptions();
            colorDrop.AddOptions(colors);
            priceText.text = "$"+ flow.cost.ToString();
            centerText.text = flow.meaning;
            flowerOrder.sprite = Resources.Load<Sprite>(flower);
            flowerOrder.color = previewMenu.GetColor(colors[colorDrop.value]);
        }
    }

    private void MakeFlowers() {
        int orNum = int.Parse(stockDrop.options[stockDrop.value].text);
        Order order = currOrders.Find(x => x.orderNum == orNum);
        string[] split;
        int score = 0;
        workingOrder.ForEach(z=> {
            cash+=5;
            split = z.Split();
            if (fs.checkColors(order.color, split[0])) {score +=5;}
            if (order.reason.flowers.Contains(split[1])) {score +=5;}
        });
        if (score > 20) {
            cash+=5; happy +=10;
            customer.Respond(true);
        } else {
            cash+=0; happy-=10;
            customer.Respond(false);
        }
        currOrders.Remove(order);
        orderScript.ManageOrders(currOrders);
        UpdateText();
        workingOrder.Clear(); 
        previewMenu.ClearMenu();
        OrderMenu.SetActive(false); stockMenu.SetActive(false);
        stockDrop.value = 0;
    }

    private void OrderStock() {
        string flower = flowerDrop.options[flowerDrop.value].text;
        string color = colorDrop.options[colorDrop.value].text;
        string cor = color+" "+flower;
        Flower flow = flowList.Find(x=> x.name == flower);
        cash-=flow.cost*(quantityDrop.value+1);
        if (enRoute.Exists(y=> y.item == cor)){
            enRoute.Find(y=> y.item == cor).quantity +=(quantityDrop.value+1);
        } else {
            enRoute.Add(new StockItem(color, flower, (quantityDrop.value+1)));
        }
        UpdateText();
        colorDrop.value = 0; flowerDrop.value = 0;
        OrderMenu.SetActive(false);
    }
}
